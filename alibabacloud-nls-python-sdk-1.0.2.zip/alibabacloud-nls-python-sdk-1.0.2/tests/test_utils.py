# Copyright (c) Alibaba, Inc. and its affiliates.

import os

# only for test
TEST_ACCESS_AKID = os.environ['TEST_ACCESS_AKID']
TEST_ACCESS_AKKEY = os.environ['TEST_ACCESS_AKKEY']
TEST_ACCESS_TOKEN = os.environ['TEST_ACCESS_TOKEN']
TEST_ACCESS_APPKEY = os.environ['TEST_ACCESS_APPKEY']

